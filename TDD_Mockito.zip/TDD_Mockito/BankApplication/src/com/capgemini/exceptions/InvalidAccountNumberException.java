package com.capgemini.exceptions;

public class InvalidAccountNumberException extends Exception {

}
