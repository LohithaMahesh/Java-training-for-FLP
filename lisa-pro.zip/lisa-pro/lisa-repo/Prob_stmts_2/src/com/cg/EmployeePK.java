package com.cg;

import com.cg.EmployeePK;

public class EmployeePK {
	int id;
	String entity;
		public EmployeePK(){}
		public EmployeePK(int id, String entity){
			this.id=id;
			this.entity=entity;
		}
		public void putId(int id){
			this.id=id;
			}
				public void putEntity(String entity){
					this.entity=entity;
					}
						public int getId(){
							return id;
							}
								public String getEntity(){
									return entity;
									}
	@Override
	public boolean equals(Object obj) {
	System.out.println("inside equals");
	boolean flag;
	flag = ((this.id == ((EmployeePK)obj).id) && (this.entity.equals(((EmployeePK)obj).entity)));
	
	return flag;	
	}	
	@Override
	public int hashCode() {
		return entity.hashCode();
		
	}
}
