package com.cg;

import java.util.HashMap;

public class Employee {
	
	int id;
	String name;
	String entity;
	String department;


public Employee(){}
	public Employee(int id, String name, String entity, String department){
		this.id=id;
		this.name=name;
		this.entity=entity;
		this.department=department;
	}
	public boolean equals(Object obj) {
		if(!(obj instanceof Employee))
		return false;
		else {
		return true;
		}

	}
public void setId(int id){
	this.id=id;
	}
		public int getId(){
			return id;
			}
				public void setName(String name){
					this.name=name;
					}
						public String getName(){
							return name;
							}
								public void setEntity(String entity){
									this.entity=entity;
									}
										public String getEntity(){
											return entity;
											}
												public void setDepartment(String department){
													this.department=department;
													}
														public String getDepartment(){
															return department;
															}
														
													
														@Override
														public String toString() {
															// TODO Auto-generated method stub
															return name + "/" + entity;
														}
	}


