import java.util.HashMap;
import java.util.HashSet;

import com.cg.Employee;
import com.cg.EmployeePK;

public class Entry {
		public static void main(String args[]){
			
	HashMap< EmployeePK, Employee> entries;
	entries = new HashMap<>();
		
	EmployeePK key1 = new EmployeePK(1001, "FS");
	Employee e1 = new Employee(1001, "lohitha", "FS", "mainframes");
	entries.put(key1, e1);

	EmployeePK key2 = new EmployeePK(1002, "NonFS");
	Employee e2 = new Employee(1002, "Mahesh", "FS", "mainframes");
	entries.put(key2, e2);
	
	EmployeePK key3 = new EmployeePK(1003, "FS");
	Employee e3 = new Employee(1003, "Sweety", "FS", "mainframes");
	entries.put(key3, e3);
	
	EmployeePK key4 = new EmployeePK(1004, "FS");
	Employee e4 = new Employee(1004, "Bhagi", "FS", "mainframes");
	entries.put(key4, e4);

	//searching key here
	EmployeePK newKey = new EmployeePK(1002, "FS");
	/*EmployeePK newKey1 = new EmployeePK(1002,"nonFS");*/

Employee retrievedEmployee = search(entries, newKey);
	
	System.out.println(retrievedEmployee);
	
	
		}
	public static <EmployeePK> Employee search(HashMap<EmployeePK, Employee> map, EmployeePK newkey){
		return map.get(newkey);
	}
}
	
