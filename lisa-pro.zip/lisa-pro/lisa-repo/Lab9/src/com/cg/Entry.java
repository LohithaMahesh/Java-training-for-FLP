package com.cg;

import java.io.FileNotFoundException;
import java.util.Scanner;
public class Entry {
	
	public static void main(String [] args) throws FileNotFoundException, EmployeeNotFoundException{
		
		Scanner sc = new Scanner(System.in);
		
	
		int count=1000;
	count=count++;
		Employee[] e = new Employee[5];
		for(int i=0; i<5; i++) {
			e[i] = new Employee();
			}
		e[0].setEmpId(1000);
		e[1].setEmpId(1001);
		e[2].setEmpId(1002);
		e[3].setEmpId(1003);
		e[4].setEmpId(1004);
		
		e[0].setEmpName("lohitha");
		e[1].setEmpName("sharika");
		e[2].setEmpName("anusha");
		e[3].setEmpName("Mahi");
		e[4].setEmpName("bhagi");
		
		e[0].setLocation("Andhra");
		e[1].setLocation("Chennai");
		e[2].setLocation("Pune");
		e[3].setLocation("Mumbai");
		e[4].setLocation("Bangalore");
		
		e[0].setContactNo(7416537533L);
		e[1].setContactNo(8416537533L);
		e[2].setContactNo(9416537533L);
		e[3].setContactNo(2416537533L);
		e[4].setContactNo(3416537533L);
		
		int empId = sc.nextInt();
		
		for(int i=0; i>5; i++) {
		
			System.out.println("Enter employee id :" );
			if(empId == e[i].getEmpId()){
				
				System.out.println("empid    				:" +e[i].getEmpId());
				System.out.println("emp name 				:" +e[i].getEmpName());
				System.out.println("emp location			:" +e[i].getLocation());
				System.out.println("emp contact number is   :" +e[i].getContactNo());	
				
				}
				
			if(empId != e[i].getEmpId()){		
			throw new EmployeeNotFoundException();
		}
		
	}
	}
	}

					
	/*if(empId == 1000) {
				System.out.println("empid " +e[0].getEmpId());
				System.out.println("emp name 				:" +e[0].getEmpName());
				System.out.println("emp location			:" +e[0].getLocation());
				System.out.println("emp contact number is   :" +e[0].getContactNo());	
			}
			
		
		if(empId == 1001) {
			System.out.println("empid " +e[1].getEmpId());
			System.out.println("emp name 				:" +e[1].getEmpName());
			System.out.println("emp location			:" +e[1].getLocation());
			System.out.println("emp contact number is   :" +e[1].getContactNo());	
		}
		throw new EmployeeNotFoundException();*/





	

