package com.cg;

public class Employee {
    int empId;
	String empName;
	String location;
	long contactNo;
		
		public Employee(int empId, String empName, String location, long contactNo){
			this.empId=empId;
			this.empName=empName;
			this.location=location;
			this.contactNo=contactNo;
		}
				
		public Employee() {
			// TODO Auto-generated constructor stub
		}
		
		public void setEmpId(int empId){
			this.empId=empId;
		}
		public int getEmpId(){
			return empId;
		}
		public void setEmpName(String empName) {
			this.empName=empName;
		}
		public String getEmpName(){
			return empName;
		}
		public void setLocation(String location) {
			this.location=location;
		}
		public String getLocation(){
			return location;
		}
		public void setContactNo(long contactNo) {
			this.contactNo=contactNo;
		}
		public long getContactNo(){
			return contactNo;
		}

		
}
