package com.cg;

public class NetworkFailureException extends Exception{

	public NetworkFailureException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NetworkFailureException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
