package com.cg;

public class Bank {
	public static final int length = 0;
	int showBalance;
	Account account;
	public Bank(int showBalance){
		this.showBalance=showBalance;
		}
	public Bank(int id, double initialBalance, boolean deposit, boolean withdraw) {
		super();
		// TODO Auto-generated constructor stub
	}
	public Bank(){}
	public void setShowBalance(int showBalance){
		this.showBalance=showBalance;
	}
	public int getShowBalance(){
		return showBalance;
	}
	public Account getAccount() {
		return account;
	}
	
}
