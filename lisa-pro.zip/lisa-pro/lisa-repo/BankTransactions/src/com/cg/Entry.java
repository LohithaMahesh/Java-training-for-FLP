package com.cg;

public class Entry {
	public static void main(String [] args){
	int i;	
		Account[] acc1 = new Account[5];
		Account[] acc2 = new Account[5];
		Bank[] b = new Account[5];
	//	Teller[] t = new Teller[2];
		
	for(i=0; i<5;i++) {
		acc1[i] = new Account();
		acc2[i] = new Account();
		b[i] = new Bank();
	}
		
	acc1[0].setId(1001);
	acc2[1].setId(1002);
	
	acc1[0].setBalance(250000);
	acc2[1].setBalance(300000);
	
	acc1[0].deposit(500);
	acc1[0].withdraw(3000);
	
	acc2[1].deposit(250);
	acc2[1].withdraw(3500);
		
	//	for(i=0; i<1;i++){
			 
  //      System.out.println("The deposit amount is" +acc1[i].getBalance());
    //    System.out.println("The deposit amount is" +acc2[i].getBalance());
  //      System.out.println("The deposit amount is" +acc1[i].getShowBalance());
  //      System.out.println("The deposit amount is" +acc2[i].getShowBalance());
        
  //	System.out.println("The deposit amount is" +acc2[i]+ acc2.deposit);
		
}
	public void printBank(Bank b1){
		
		
		System.out.println("Account 1 balance is :" +b1.getShowBalance());
		
		
		for(int i=0; i<b1.length; i++){
			
			System.out.println(b[i].getBalance());
			
		}
		
		
	}
	
	}

	

