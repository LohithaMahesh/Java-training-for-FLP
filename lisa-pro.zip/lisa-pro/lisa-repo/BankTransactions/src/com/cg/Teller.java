package com.cg;

public class Teller extends Bank {
	
public void performTransfer(Account bankAccount, Account toAccount,int amount) {
		 withdraw(amount);
		
  }

private void withdraw(int amount) {
	// TODO Auto-generated method stub
	
}
}

