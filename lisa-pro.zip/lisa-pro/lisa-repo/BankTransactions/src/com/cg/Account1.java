package com.cg;

public class Account1 {
		private int ANumber;
		private double balance;

		public Account1(double initialBalance, int accno) {
		    balance = initialBalance;
		    ANumber = accno;
		}

		public void deposit (double amt){
		    balance += amt;
		}

		public double withdraw(double amt) {
		    balance -= amt;
		    return amt;
		}

		public double getBalance() {
		    return balance;
		}
		public int getAccount(){
		    return ANumber;
		}
		}