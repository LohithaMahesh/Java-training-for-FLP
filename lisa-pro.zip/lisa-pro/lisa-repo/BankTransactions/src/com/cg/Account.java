package com.cg;

public class Account extends Bank {
		int id;
		double balance;
		private boolean deposit;
		private boolean withdraw;
		
		public Account(int id, double initialBalance, boolean deposit, boolean withdraw) {
			
			super(id, initialBalance, deposit, withdraw);
			this.id=id;
			balance=initialBalance;
			this.deposit=deposit;
			this.withdraw=withdraw;
			
		}
		
		public Account() {
		
		}

		public void setId(int id){
			this.id=id;
			}
		public int getId(){
			return id;
			}
		public void setBalance(double balance){
			this.balance=25000;
		}
		
		public void deposit(double amount)
		{
			balance = balance + amount;
		}
		

		public double getBalance(){
			return balance;
		}
		public void withdraw(double amount)
		{
			balance = balance - amount;
			if(balance < 0) {
				sendWarning();
			}
		}
		
		private void sendWarning() {
			System.out.println("Your account have Zero balance");
			
		}
		public double displayBalance(){
			return balance;
		}

		
		 
		

}
