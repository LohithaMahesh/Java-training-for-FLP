package com.cg;

public interface EmployeeDetails {

	Employee getDetail(int id);

}
