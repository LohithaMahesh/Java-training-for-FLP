package com.cg;
import java.util.Properties;
import java.util.Scanner;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
 
//import com.bullraider.services.business.Employee;
//import com.bullraider.services.business.EmployeeDetails;
public class Entry{
    public static void main(String[] args) {
 
       Properties props = new Properties();
        props.put("java.naming.factory.initial", "org.jboss.naming.HttpNamingContextFactory" );
        props.put("java.naming.provider.url", "http://localhost:8080/invoker/JNDIFactory");
        props.put("java.naming.factory.url.pkgs", "org.jboss.naming");
 
        try {
            Context context = new InitialContext(props);
            try {
                Scanner sc=new Scanner(System.in);
                System.out.println("Please enter id i.e 1 or 2");
                int id=sc.nextInt();
                EmployeeDetails emplyService = (EmployeeDetails)context.lookup("EmployeeDetailBean/remote");
                Employee e=emplyService.getDetail(id);
                if(e!=null){
                System.out.println( "Employee Name:"+ e.getName()+" Sal: "+e.getSal());
                }else{
                    System.out.println("No Such Employee found");
                }
            }
            catch (NamingException e) {
                System.out.println("couldn't look up ");
                e.printStackTrace();
            }
        } catch (NamingException e) {
            System.out.println("naming exception occoured");
            e.printStackTrace();
        }
    }
}
