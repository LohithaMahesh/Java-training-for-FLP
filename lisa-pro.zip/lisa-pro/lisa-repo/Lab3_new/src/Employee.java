
public class Employee {
	private String name;
	private double salary;
	String joinDate;
	private static int count;
	
	public Employee(String name, double salary, String joinDate) {
		this.name=name;
		this.salary=salary;
		this.joinDate=joinDate;
		
	
		
	}
}