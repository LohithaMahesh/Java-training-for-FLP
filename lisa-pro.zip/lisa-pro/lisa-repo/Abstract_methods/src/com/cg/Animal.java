package com.cg;

public class Animal {

}
