package com.cg;

public class Dog {

}
