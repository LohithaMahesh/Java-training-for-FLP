package com.cg;

public class Entry {

}
