package com.cg;

public class LinkedList
{
	 class Node{
	    	private int data;
	    	private Node next;
	    	
	    	public Node(int data){
	    		this.data=data;
	    		
	    	}
	    }
	 // TODO Create an inner class Node
    
   //TODO a inside linked list, add member variable which is pointing to the first node
    	
    	private Node head, last;
    	
    	public boolean add(int data){
  
    		// TODO create a new node and set the data
    	
    		Node nn = this.new Node(data);
   
//    		TODO Check if LinkedList is empty
    		
    		if(head==null){
    			head = last = nn;
    		}else{
    		
    			last.next=nn;
    			last=nn;
    		
    		}
    		return true;
    	}

 //TODO add a method to display a list

    public void display(){
    	Node temp = head;
    	
    	while(temp != null){
    	System.out.println(temp.data + "\t");
    	temp = temp.next;
    	}
    	
    }
   
}


   
 
    