package com.cg;
import java.util.collection;
public class Interface {

	public static void main(String[] args) {
		
	}
}
