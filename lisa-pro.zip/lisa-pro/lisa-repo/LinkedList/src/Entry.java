import com.cg.LinkedList;
import java.util.Collection;
import java.util.List;
public class Entry {
	public static void main(String[] args) {

		LinkedList list1 = new LinkedList();
    	list1.add(10);
    	list1.add(30);
    	list1.add(40);
    	list1.add(20);
    	
    	list1.display();
    		
    		LinkedList l2 = new LinkedList();
        	
        	l2.add(10);
        	l2.add(30);
        	l2.add(40);
        	l2.add(20);
        	
        	l2.display();
        			
    	}
    }
	
