package com.cg;
public class Employee {
	String name;
	Address address;
		
	
	public void setName(String name){
		this.name=name;
			}
	public String getName() {
		return name;
	}
	public void setAddress(Address a){
		this.address=a;
	}
	public Address getAddress(){
		return address;
		}
	}

