package com.cg;

import java.util.Comparator;

public class Product {
	
		int id;
		String name;
		Double price;
	
			public Product(int id, String name, double price){
				this.id=id;
				this.name=name;
				this.price=price;
				}

public void setId(int id){
	this.id=id;
	}
		public int getId(){
			return id;
			}
				public void setName(String name){
					this.name=name;
					}
						public String getName(){
							return name;
							}
								public void setPrice(double price){
									this.price=price;
									}
										public double getPrice(){
											return price;
											}


public String toString(){
	return this.id+ "/" +this.name + "/" +this.price;
}

}
class MyIdWise implements Comparator<Product> {

	public int compare(Product pro1, Product pro2) {
		if (pro1.getId() > pro2.getId()){
		return 1;
	}else{
		return -1;
	}
	}
}
class MyPriceWise implements Comparator<Product> {

@Override
public int compare(Product pro1, Product pro2) {
  
if (pro1.getPrice() > pro2.getPrice()){
return 1;
}else{
return -1;
}
}
}




