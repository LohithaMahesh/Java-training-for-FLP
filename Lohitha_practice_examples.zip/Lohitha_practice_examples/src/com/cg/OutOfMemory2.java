package com.cg;

import java.util.ArrayList;
import java.util.List;

public class OutOfMemory2 {
	 // static List<String> list= new ArrayList<String>();
	 
	 public static void main(String[] args) throws Exception {
		
		 int[] array = new int[100000*100000];
	/*	 while(true){
			    new Thread(new Runnable(){
			        public void run() {
			            try {
			                Thread.sleep(1000);
			            } catch(InterruptedException e) { }        
			        }    
			    }).start();
			}

	}*/
	 
	 }
}
