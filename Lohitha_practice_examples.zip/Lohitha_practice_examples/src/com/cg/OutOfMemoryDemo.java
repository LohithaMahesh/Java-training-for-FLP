package com.cg;

import java.util.List;
import java.util.ArrayList;


public class OutOfMemoryDemo {
	private static List heaplist=new ArrayList();
	public static void main(String[] args) {
			while(true){
				heaplist.add(new String("Lohitha"));
				
			}
		
	}

}
