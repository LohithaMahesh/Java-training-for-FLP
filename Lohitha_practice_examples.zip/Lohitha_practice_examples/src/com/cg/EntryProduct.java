package com.cg;


import java.util.TreeSet;

import com.cg.Product;

public class EntryProduct {
	public static void main(String [] args){

		TreeSet<Product>  MyIdWise = new TreeSet<Product>(new MyIdWise());
	        MyIdWise.add(new Product(100, "Santoor",3000));
	        MyIdWise.add(new Product(106, "Vivel",1000));
	        MyIdWise.add(new Product(105, "Godrej",1500));
	        MyIdWise.add(new Product(103, "Garnier",2500));
	        MyIdWise.add(new Product(103, "Garnier",2500));
	        MyIdWise.add(new Product(104, "Loreal Paris",4500));
	        
	        for(Product pro: MyIdWise){
	        	System.out.println(pro);
	        }
	        System.out.println("======================================================");
	        TreeSet<Product>  MyPriceWise = new TreeSet<Product>(new MyPriceWise());
	        MyPriceWise.add(new Product(100, "Santoor",3000));
	        MyPriceWise.add(new Product(106, "Vivel",1000));
	        MyPriceWise.add(new Product(105, "Godrej",1500));
	        MyPriceWise.add(new Product(103, "Garnier",2500));
	        MyPriceWise.add(new Product(105, "Godrej",1500));
	        MyPriceWise.add(new Product(104, "Loreal Paris",4500));
	        
	        for(Product pro: MyPriceWise){
	        	System.out.println(pro);
	        }
	        
	}
}




	


	


