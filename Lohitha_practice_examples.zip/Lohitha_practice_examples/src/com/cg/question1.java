package com.cg;


class A extends Thread {
	  String[] sa;
	  public A(String[] sa) {this.sa = sa;}
	  public void run() {
	    synchronized (sa) {
	      while (!sa[0].equals("Done")) {
	        try {sa.wait();} catch (InterruptedException ie) {}
	    }}
	    System.out.print(sa[1] + sa[2] + sa[3]);
	}}
	class B {
	  private static String[] sa = new String[]{"Not Done","X","Y","Z"};
	  public static void main (String[] args) {
	    Thread t1 = new A(sa); t1.start();
	    synchronized (sa) {
	      sa[0] = "Done";
	      sa[1] = "A"; sa[2] = "B"; sa[3] = "C";
	      sa.notify();
	}}}






