package com.cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
//TCP/IP code with HTTP
public class httpRequestSample {
	public static void main(String[] args) throws IOException {
		
		ServerSocket service = new ServerSocket(805);
		
		
		System.out.println("Waiting for client connection");
		
		while(true){
			final Socket clientSocket = service.accept();
			
		
			
//			System.out.println("Client is now connected");
//			System.out.println(clientSocket);
			
			new Thread(
					
						new Runnable() {
							
							public void run() {
								
								try {
									
									// TODO read HTTP request and print it on console.
									InputStream in = clientSocket.getInputStream();
									InputStreamReader iReader = new InputStreamReader(in);
					
									BufferedReader buff = new BufferedReader(iReader);
									
											String requestFormat = null;
	// It will read the client data until the buffered reader is empty, once the buffered reader is empty,
	// it gives us false until the buffered reader has it will keep on reading that data.										
											
											do {
												
												requestFormat = buff.readLine();
												System.out.println(requestFormat);
												
											}while(buff.ready());
										
									
									
									// TODO preparing a HTTp response and sending it.
									OutputStream out = clientSocket.getOutputStream();
									
									PrintWriter pOut = new PrintWriter(out,true);
									System.out.println("sending response "+ clientSocket);
									pOut.println("HTTP/101 200 Ok");
									pOut.println();
									pOut.println("hello, World");
									pOut.close();
								} catch (IOException e) {
									e.printStackTrace();
								}
							}
						}
						).start();
		}
	}
}


