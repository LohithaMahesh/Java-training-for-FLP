package com.cg.util;

import java.lang.Comparable;
import java.util.TreeSet;

public class Person implements Comparable {
	String userName;
	int age;
	//public Person( ) {}
	public Person(String userName, int age){
		this.userName=userName;
		this.age=age;
			}
/*	public boolean equals(Object obj){
		
		if ( !(obj instanceof Person))
	         {
	//	if(this.userName.equals (((Person) obj).userName))
	//	{
		return true;
		}else
		{
		return false;
		}
	
}
*/
	public boolean equals(Object obj){
		if(!(obj instanceof Person))
		return false;
		return this.userName.equals(((Person)obj).userName);
	//	return this.age.equals(((Person)obj).age);
	}
	public int compareTo(Object o){
		System.out.println("comparing" +this+ " with " +age);
		
		int diff = this.age - ((Person)o).age;
		return diff;
	}
	public String toString(){
		return userName + "\t" +age;
	}


	}


