public class Employee
{

	public Employee(int id, String fName, String sName, double Salary, char Grade, String jDate)
	{
		System.out.println("The id of employee is       :"+ id);
		System.out.println("The fName of employee is    :"+ fName);
		System.out.println("The sName of employee is    :"+ sName);
		System.out.println("The Salary of employee is   :"+ Salary);
		System.out.println("The grade of employee is    :"+ Grade);
		System.out.println("The jDate of employee is    :"+ jDate);
		System.out.println("----------------------------------------------------------------");
	}
}
