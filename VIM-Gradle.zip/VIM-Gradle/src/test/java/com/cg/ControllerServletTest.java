package com.cg;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class ControllerServletTest {

	@Test
	@Ignore
	public void testProcessRequest() {
		fail("Not yet implemented");
	}

}
