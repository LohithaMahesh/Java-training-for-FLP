package demo.repo;

import java.util.HashMap;
import java.util.Map;

import demo.beens.Customer;


public class Repo implements walletRepo {
Map<String,Customer> data;
	
	public Repo(Map<String, Customer> data)
	{
		this.data = data;
	}

	public boolean save(Customer c) {
		String mobileNumber = c.getMobileNumber();
		data.put(mobileNumber, c);
		return true;
	}
	public Customer findOne(String mobileNumber) 
	{
		Customer c = data.get(mobileNumber);
		return c;
	}

}
