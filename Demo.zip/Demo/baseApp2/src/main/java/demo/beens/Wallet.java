package demo.beens;

import java.util.HashMap;
import java.util.Map;



public class Wallet {


	float balance;

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}
}
