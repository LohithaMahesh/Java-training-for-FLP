package demo.repo;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import demo.beens.Customer;

@Repository
public class Repo implements walletRepo {
@Resource(name="some")

private Map<String,Customer> data;
	

/*	public Repo(Map<String, Customer> data)
	{
		this.data = data;
	}
*/
	public boolean save(Customer c) {
		String mobileNumber = c.getMobileNumber();
		data.put(mobileNumber, c);
		return true;
	}
	public Customer findOne(String mobileNumber) 
	{
		Customer c = data.get(mobileNumber);
		return c;
	}

}
