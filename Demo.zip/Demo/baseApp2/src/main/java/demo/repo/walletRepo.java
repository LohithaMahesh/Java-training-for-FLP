package demo.repo;
import java.util.Map;

import demo.beens.*;
public interface walletRepo {

	public boolean save(Customer c);
	Customer findOne(String mobileNumber);

}
