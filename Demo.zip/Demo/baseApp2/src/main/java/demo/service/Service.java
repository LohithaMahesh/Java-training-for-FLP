package demo.service;

import org.springframework.beans.factory.annotation.Autowired;

import demo.beens.*;
import demo.repo.*;
@org.springframework.stereotype.Service(value="service")

public class Service implements walletService{
	@Autowired
	private walletRepo wrepo;


	/*	public Service(walletRepo wrepo) {
		this.wrepo = wrepo;
	}
	 */
	public Customer createAccount(String name, String mobileNumber, float amount)
	{
		Customer c = new Customer();
		Wallet w = new Wallet(); 
		w.setBalance(amount);
		c.setName(name);
		c.setMobileNumber(mobileNumber);
		c.setWallet(w);
		wrepo.save(c);
		return c;
	}
	public Customer showBalance(String mobileNumber)
	{
		Customer c = wrepo.findOne(mobileNumber);
		wrepo.findOne(mobileNumber);
		return c;
	}
	public boolean withdraw(float amount,String mobileNumber)
	{
		Customer c=wrepo.findOne(mobileNumber);
		if(amount < c.getWallet().getBalance())
		{
			Wallet w = c.getWallet();
			w.setBalance(c.getWallet().getBalance() - amount);
			c.setWallet(w);
			wrepo.save(c);
			return true;
		}
		else
			return false;
	}

	public boolean deposit(float amount,String mobileNumber)
	{
		Customer c = wrepo.findOne(mobileNumber);
		Wallet w = c.getWallet(); 
		System.out.println(c.getWallet().getBalance() + amount);
		w.setBalance(w.getBalance() + amount);
		c.setWallet(w);
		wrepo.save(c);
		return true;
	}

}
