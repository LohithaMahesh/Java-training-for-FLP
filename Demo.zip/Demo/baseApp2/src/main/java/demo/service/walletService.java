package demo.service;

import demo.beens.*;
import demo.repo.walletRepo;

public interface walletService {

	 public Customer createAccount(String name, String mobileNumber,float amount);
	  public Customer showBalance(String mobileNumber);
	  public boolean withdraw(float ammount,String mobileNumber);
	  public boolean deposit(float ammount,String mobileNumber);

}
