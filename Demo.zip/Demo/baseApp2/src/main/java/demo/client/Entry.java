package demo.client;
import demo.service.*;
import demo.repo.*;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.support.GenericXmlApplicationContext;

import demo.beens.*;

public class Entry {
	public static void main(String args[])
	{
		//Map<String,Customer> map = new HashMap<>();
	//	walletRepo repo =new Repo(map);
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("demo/client/beanconfig.xml");
    	walletService service = ctx.getBean("service",demo.service.Service.class);
     
		Wallet wallet = new Wallet();
		wallet.setBalance(750f);
		
		Customer customer1 = new Customer();  
		customer1.setName("bunny");
		customer1.setMobileNumber("8328398752");
		customer1.setWallet(wallet);
		
		Wallet wallet2 = new Wallet();
		wallet2.setBalance(650f);
		
		Customer customer2 = new Customer();  
		customer2.setName("chandu");
		customer2.setMobileNumber("9876543210");
		customer2.setWallet(wallet2);
		
	//	walletService service = new Service(repo);  
		
		service.createAccount(customer1.getName(),customer1.getMobileNumber(),customer1.getWallet().getBalance());
		System.out.println("Account " + customer1.getName() + " Created");
		System.out.println("Name : " + customer1.getName() + " Mobile Number : " + customer1.getMobileNumber()+ " Balance " + wallet.getBalance());
		service.showBalance("8328398752");
		System.out.println("Your Available balance is : " + wallet.getBalance());
		
		System.out.println();
		
		service.createAccount(customer2.getName(),customer2.getMobileNumber(),customer2.getWallet().getBalance());
		System.out.println("Account " + customer2.getName() + " Created");
		System.out.println("Name : " + customer2.getName() + " Mobile Number : " + customer2.getMobileNumber()+ " Balance " + wallet2.getBalance());
		service.showBalance("9876543210");
		System.out.println("Your Available balance is : " + wallet2.getBalance());
		
		System.out.println(service.deposit(500,"8328398752"));
		System.out.println(service.withdraw(200,"8328398752"));
		

		
	   Customer c= service.showBalance("8328398752");
	   Wallet w= c.getWallet();
	   System.out.println("Account " + c.getName() );
	   System.out.println("Name : " + c.getName());
	   System.out.println(" Mobile Number : " + c.getMobileNumber());
       System.out.println( " Balance " + w.getBalance());	
	}

}
