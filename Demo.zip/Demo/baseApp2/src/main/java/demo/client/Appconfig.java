package demo.client;

public class Appconfig {

}
