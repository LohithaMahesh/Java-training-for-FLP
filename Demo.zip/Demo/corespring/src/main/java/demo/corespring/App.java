package demo.corespring;

import org.springframework.context.support.GenericXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("demo/corespring/beanconfig.xml");
    	MessageService service = ctx.getBean("msg",MessageService.class);
      	service.printMessage();
    }
}
