package demo.corespring;

public class MessageService {
	private Message msg;
	
   public MessageService(Message msg) {
		super();
		this.msg = msg;
	}

public void printMessage(){
	System.out.println(msg.getText());
}
}
