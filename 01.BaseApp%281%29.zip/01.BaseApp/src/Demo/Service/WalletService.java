package Demo.Service;

import Demo.Bins.Customer;

public interface WalletService 
{
  public Customer createAccount(String name, String mobileNumber,float amount);
  public Customer showBalance(String mobileNumber);
}
