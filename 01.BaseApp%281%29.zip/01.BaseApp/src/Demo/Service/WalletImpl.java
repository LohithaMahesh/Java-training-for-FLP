package Demo.Service;

import Demo.Bins.Customer;
import Demo.Bins.Wallet;
import Demo.Repo.WalletRepo;
import Demo.Repo.WalletRepoImpl;

public class WalletImpl implements WalletService 
{
	private WalletRepo wrepo;
	
	public WalletImpl(WalletRepo wrepo) {
		this.wrepo = wrepo;
	}

	@Override
	public Customer createAccount(String name, String mobileNumber, float amount)
	{
		Customer c = new Customer();
		Wallet w = new Wallet(); 
		w.setBalance(amount);
		
		c.setName(name);
		c.setMobileNumber(mobileNumber);
		c.setWallet(w);
		wrepo.save(c);
		
		return c;
		
				
	
	}

	@Override
	public Customer showBalance(String mobileNumber)
	{
		Customer c = wrepo.findOne(mobileNumber);
		wrepo.findOne(mobileNumber);
		return c;
	}
	

}
