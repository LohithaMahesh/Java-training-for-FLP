package Demo.Client;

import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.css.CSSUnknownRule;

import Demo.Bins.Customer;
import Demo.Bins.Wallet;
import Demo.Repo.WalletRepo;
import Demo.Repo.WalletRepoImpl;
import Demo.Service.WalletImpl;
import Demo.Service.WalletService;

public class Main 
{
	public static void main(String args[])
	{
		Map<String,Customer> map = new HashMap<>();
		WalletRepo repo =new WalletRepoImpl(map);
		Wallet wallet = new Wallet();
		wallet.setBalance(500f);
		
		Customer customer1 = new Customer();  
		customer1.setName("Radha");
		customer1.setMobileNumber("7845965841");
		customer1.setWallet(wallet);
		
		Wallet wallet2 = new Wallet();
		wallet2.setBalance(800f);
		
		Customer customer2 = new Customer();  
		customer2.setName("Sidd");
		customer2.setMobileNumber("1234567890");
		customer2.setWallet(wallet2);
		
		WalletService service = new WalletImpl(repo);  
		
		service.createAccount(customer1.getName(),customer1.getMobileNumber(),wallet.getBalance());
		System.out.println("Account " + customer1.getName() + " Created.....");
		System.out.println("Name : " + customer1.getName() + " Mobile Number : " + customer1.getMobileNumber()+ " Balance " + wallet.getBalance());
		service.showBalance("7845965841");
		System.out.println("Your Available balance is : " + wallet.getBalance());
		
		System.out.println();
		
		service.createAccount(customer2.getName(),customer2.getMobileNumber(),wallet2.getBalance());
		System.out.println("Account " + customer2.getName() + " Created.....");
		System.out.println("Name : " + customer2.getName() + " Mobile Number : " + customer2.getMobileNumber()+ " Balance " + wallet2.getBalance());
		service.showBalance("1234567890");
		System.out.println("Your Available balance is : " + wallet2.getBalance());
	}
}
