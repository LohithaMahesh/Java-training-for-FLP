package com.cg;

public class Entry {
	public static void main(String [] args){
		Account a1 = new Account("Lohitha", 25000);
	}

}
