package com.cg;

public class Account {
	private  long accountNumber;
	private double balance;
	private String name;
	
	public Account(String owner, long account, double initial){
		name=owner;
		accountNumber=account;
		balance=initial;
	}
	public double deposit(deposit amount){
		this.balance=balance;
		return this.balance;
	}
	public double getBalance(){
		return this.balance;
	}
	public String toString(){
		System.out.println(this.accountNumber + "\t" + this.name + "\t" + getBalance());
		return name;
	}
	}
