package com.cg;

import java.util.Comparator;

public class Employee {
	
	    
		String empName;
		double salary;
		
			
			public Employee( String empName, double salary){
				
				this.empName=empName;
				this.salary=salary;
				
				}
					public boolean equals(Object obj) {
							if(!(obj instanceof Employee))
							return false;
							else {
							return true;
							}
				
			
			
			}
			public void setEmpName(String empName){
				this.empName=empName;
				}
					public String getEmpName(){
						return empName;
						}
							public void setSalary(double salary){
								this.salary=salary;
								}
									public double getSalary(){
										return salary;
										}
			
			public String toString(){
				return "the employee :" + this.empName + " has salary		:" + this.salary;
				}
			}


class MyNameComp implements Comparator<Employee>{
	 
    @Override
    public int compare(Employee e1, Employee e2) {
        return e1.getEmpName().compareTo(e2.getEmpName());
    	}
	}   
class MySalaryComp implements Comparator<Employee>{
	 
    @Override
    public int compare(Employee e1, Employee e2) {
        	if(e1.getSalary() > e2.getSalary()){
        		return 1;
        		} 
        			else
        			{
        				return -1;
        				}
    		}
}			
