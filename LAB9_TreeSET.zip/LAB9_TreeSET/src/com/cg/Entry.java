package com.cg;
import java.util.HashSet;
import java.util.Comparator;
import java.util.TreeSet;
public class Entry {
	
		public static void main(String[] args) {
	
			TreeSet<Employee> nameComp = new TreeSet<Employee>(new MyNameComp());
				
				Employee e1 = new Employee("Lohi"   , 2800);
				nameComp.add(e1);
				Employee e2 = new Employee("Bhagi"  , 6000);
				nameComp.add(e2);
				Employee e3 = new Employee("Mahesh",  8000);
				nameComp.add(e3);
				Employee e4 = new Employee("Lohitha", 7000);
				nameComp.add(e4);
				
				
					
						System.out.println("=================================================================");
     
     		TreeSet<Employee> salComp = new TreeSet<Employee>(new MySalaryComp());
     
     			salComp.add(new Employee("Lohi"   ,	3000));
     			salComp.add(new Employee("Bhagi"  ,	6000));
     			salComp.add(new Employee("Manisha",	2000));
     			salComp.add(new Employee("Sharika",	2400));
     
     		/*			for(Employee e2:salComp){
     						System.out.println(e2);
     						}
*/
		}
}
