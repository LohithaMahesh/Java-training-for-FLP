package com.cg;

public class Country {
	String name;
	City city;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name){
		this.name=name;
			}
	public void setCity(City c2){
		this.city=c2;
	}
	public City getCity(){
		return city;
		}
}
