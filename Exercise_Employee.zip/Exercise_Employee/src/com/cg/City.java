package com.cg;


public class City {
	String name;
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name){
		this.name=name;
			}
	
}

