package com.cg;

public class Entry {
		
	public static void main(String args[]){
		Employee[] e = new Employee [5];
		Address[] a = new Address[5];
		Country[] con= new Country[5];
		City[] c = new City[5];
		
		int i;
		for(i=0; i<5; i++) {
			e[i] = new Employee();
			a[i]= new Address();
			con[i]=new Country();
			c[i]=new City();
	    
		}
			e[0].setName("Lohitha");
		    e[1].setName("Sharika");
		    e[2].setName("Anusha");
		    e[3].setName("Preethi");
		    e[4].setName("Manisha");
		
		    
		    
		    	a[0].setLine("M");
		    	a[1].setLine("T");
		    	a[2].setLine("A");
		    	a[3].setLine("B");
		    	a[4].setLine("D");
		    	
		    	
		    	
		    		con[0].setName("India");
		    		con[1].setName("USA");
		    		con[2].setName("UK");
		    		con[3].setName("China");
		    		con[4].setName("Srilanka");
		    		
		    		
		    		
		    			c[0].setName("Red");
		    			c[1].setName("Green");
		    			c[2].setName("Yellow");
		    			c[3].setName("White");
		    			c[4].setName("Black");
		    	
		    			for(i=0; i<5; i++) {
		    				e[i].setAddress(a[i]);
		    				a[i].setCountry(con[i]);
		    				con[i].setCity(c[i]);
		    			
		    	System.out.println("Employee name is    		:" +e[i].getName());
		    	System.out.println("Employee Address is	    	:" +e[i].getAddress().getLine());
		    	System.out.println("Employee Country is 		:" +e[i].getAddress().getCountry().getName());
		    	System.out.println("Employee city is    		:" +e[i].getAddress().getCountry().getCity().getName());
		    	System.out.println("------------------------------------------------------------------------------------------------");	
		    	
		    			    	
		    			}
	}
}

