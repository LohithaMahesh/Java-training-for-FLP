package demo;

public class ServletException extends Exception {

}
