Title:
------------

Core JAVAScript Language

(
	Ref: Head First JAVAScript
	Chapter#4	Decision making
) 

Notes:
--------

JAVAScript provides following decision making statement:
if-else; if-else if- else; switch

Single line comments start with //.
Multi-line comments are enclosed between /* and */.

comparison operators:
		==
		!=
		<
		>
		!
		<=
		>=




