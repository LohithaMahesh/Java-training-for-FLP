public class Entry
{
	String fName,lName,jDate;
	int sal;
	char grade;
	static int count = 0,id=1001;
	public static void main(String args[]) throws Exception
	{
		Employee e=new Employee(id++,"Siddhesh","Pednekar","Apr-2018",4000,'A');
		
		Employee e1=new Employee(id++,"Suraj","Yadav","May-2018",5000,'B');
	
		Employee e2=new Employee(id++,"Nikhil","Panvilkar","Jun-2018",6000,'C');
		
		Employee e3=new Employee(id++,"Vinayak","Gajam","Jul-2018",7000,'D');
		
		Employee e4=new Employee(id++,"Amit","Mohite","Aug-2018",8000,'E');
		
		
	}
}