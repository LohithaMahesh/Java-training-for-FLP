public class Employee
{
	public Employee(int id,String fName,String lName,String jDate,int sal,char grade, int count)
	{

		System.out.println("ID of the Employee is     : " + id);
		System.out.println("First Name of Employee is : " + fName);
		System.out.println("Last Name of Employee is  : " + lName);
		System.out.println("Salary of Employee is     : " + sal);
		System.out.println("Join date of Employee is  : " + jDate);
		System.out.println("Grade of Employee is      : " + grade);
		System.out.println(" ");

	}
}