package Demo.Repo;
import Demo.Bins.Customer;

public interface WalletRepo 
{
	public boolean save(Customer c);
	Customer findOne(String mobileNumber);

}
