package Demo.Repo;

import java.util.HashMap;
import java.util.Map;

import Demo.Bins.Customer;

public class WalletRepoImpl implements WalletRepo 
{
	Map<String,Customer> data = new HashMap<>();
	
	@Override
	public boolean save(Customer c) {
		String mobileNumber = c.getMobileNumber();
		data.put(mobileNumber, c);
		return true;
	}

	@Override
	public Customer findOne(String mobileNumber) 
	{
		Customer c = data.get(mobileNumber);
		return c;
	}

}
