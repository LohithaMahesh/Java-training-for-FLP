package Demo.Client;

import Demo.Bins.Customer;
import Demo.Bins.Wallet;
import Demo.Service.WalletImpl;
import Demo.Service.WalletService;

public class Main 
{
	public static void main(String args[])
	
	{
		
		Wallet wallet = new Wallet();
		wallet.setBalance(500f);
		
		Customer customer1 = new Customer();  
		customer1.setName("Radha");
		customer1.setMobileNumber("7845965841");
		customer1.setWallet(wallet);
		
		WalletService service = new WalletImpl();  
		
		service.createAccount(customer1.getName(),customer1.getMobileNumber(),wallet.getBalance());
		System.out.println("Account Created.....");
		System.out.println("Name : " + customer1.getName()+ " Mobile Number : " + customer1.getMobileNumber()+ " Balance " + wallet.getBalance());
		service.showBalance("7845965841");
		System.out.println("Your Available balance is : " + wallet.getBalance());
	}
}
