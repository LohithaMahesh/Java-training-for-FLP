package com.cg;

public class Player {
	private String name;
	private Game games[];
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Game[] getGames() {
		return games;
	}
	public void setGames(Game[] games) {
		this.games = games;
	}
	
	public void display()
	{
		for(int i=0;i<games.length;i++)
		{
			System.out.println("Game :"+games[i].getGameName());
		}
	}
}

