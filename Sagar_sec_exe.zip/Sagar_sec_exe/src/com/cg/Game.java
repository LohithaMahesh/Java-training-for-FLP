package com.cg;

public class Game {
	private String gameName;
	
		public Game(String gameName) {
		this.gameName=gameName;
		
	}
		public Game() {
			// TODO Auto-generated constructor stub
		}
		public void setGameName(String gameName) {
			this.gameName=gameName;
			}
		public String getGameName(){
			return gameName;
		}
		
		
	}

