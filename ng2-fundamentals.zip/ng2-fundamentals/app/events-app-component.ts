import {Component} from '@angular/core'

@Component({
    selector: 'events-app',
    template: '<h1>Hello, {{name}}</h1>'
})

export class EventsAppComponent{
     name:  string = "World!";

}