package com.Interface;

public interface MessageGateway {
  public String processTrade(String s); 
}
