package com.spring.assignment;

import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.splitter.AbstractMessageSplitter;
import org.springframework.messaging.Message;

@MessageEndpoint(value="splitterService")
public class SplitterService extends AbstractMessageSplitter{

	@Override
	protected Object splitMessage(Message<?> message) {
		System.out.println("Inside splitter:--"+message.getPayload());
		return null;
	}

}
