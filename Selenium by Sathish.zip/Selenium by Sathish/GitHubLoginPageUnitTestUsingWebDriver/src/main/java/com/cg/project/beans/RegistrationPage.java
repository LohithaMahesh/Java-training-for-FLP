package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
public class RegistrationPage {
	@FindBy(id="user_login")
	WebElement username;
	
	@FindBy(id="user_email")
	WebElement email;

	@FindBy(id="user_password")
	WebElement password;

	@FindBy(className="btn btn-primary")
	WebElement button;


	public RegistrationPage(){}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}
	public WebElement getUSername() {
		return password;
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	public WebElement getEmail() {
		return password;
	}
	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	public WebElement getPassword() {
		return password;
	}
	public void clickSubmitButton() {
		button.submit();
	}
}
