package demo.beans;

public class TestBean {

	private String name;

	public TestBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TestBean(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
