import java.util.*;
class Employee{
	static int empid;
	static int counter;
	String fname;
	String lname;
	int salary;
	String grade;
	String date;
	public void getDetails(){
		Scanner os=new Scanner(System.in);
		empid = ++counter;
		System.out.println("Enter employee first name :");
		fname = os.nextLine();
		System.out.println("Enter employee last name : ");
		lname = os.nextLine();
		System.out.println("Enter Joining Date : Format(mmm/yyyy)");
		date = os.nextLine();
		System.out.println("Enter employee grade : ");
		grade = os.nextLine();
		System.out.println("Enter employee salary : ");
		salary = os.nextInt();
	}
	
	public void Display(){
		System.out.println( +empid+ "\t" +fname+ " " +lname+ "\t" +grade+ "\t" +salary+ "\t\t" +date);
	}
}