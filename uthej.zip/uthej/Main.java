	import java.util.*;

	public class Main{
	public static void main(String args[]){
	Scanner os=new Scanner(System.in);
	System.out.println("How many records have to be entered : ");
	int n = os.nextInt();
 	Employee[] emp = new Employee[n];
	int i=0;
	for(i=0;i<emp.length;i++){
		emp[i] = new Employee();
		emp[i].getDetails();
		emp[i].Display();
	}
	Employee count = new Employee();
	System.out.println("No. of records " +count.empid);
	
}
}